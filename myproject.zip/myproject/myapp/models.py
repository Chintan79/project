from django.db import models

# Create your models here.
class user(models.Model):
    email = models.EmailField(unique=True,max_length=30)
    password = models.CharField(max_length=20)
    role = models.CharField(max_length=20)
    
    def __str__(self):
        return self.email

    
class cafe_owner(models.Model):
    user_id = models.ForeignKey(user,on_delete=models.CASCADE)
    username = models.CharField(max_length=50)
    contact = models.CharField(max_length=30)
    cafe_name = models.CharField(max_length=30)
    cafe_address = models.TextField()
    pic = models.FileField(upload_to='media/images',default='media/logo1.png')
    
    def __str__(self):
        return self.username
    
class category(models.Model):
    category_name = models.CharField(max_length=60)
    
    def __str__(self):
        return self.category_name
 
class products(models.Model):
    user_id = models.ForeignKey(user,on_delete=models.CASCADE)
    category_id = models.ForeignKey(category,on_delete=models.CASCADE)
    product_name = models.CharField(max_length=60)
    discription = models.CharField(max_length=100)
    food_type = models.CharField(max_length=30,blank=True,null=True)
    price = models.CharField(max_length=20)
    pic = models.FileField(upload_to = 'media/images',default='media/foodicon.jpg')
    
    
    def __str__(self):
        return self.product_name
