from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import *
# Create your views here.
def home(request):
    if "email" in request.session:
        uid = user.objects.get(email = request.session['email'])
        cid = cafe_owner.objects.get(user_id = uid) 
        context = {
                    'uid' : uid,
                    'cid' : cid, 
                }
        return render(request,"myapp/index.html",context)
    else:
        return render(request,"myapp/login.html")

def login(request):
    if "email" in request.POST:
        uid = user.objects.get(email = request.session['email'])
        cid = cafe_owner.objects.get(user_id = uid) 
        context = {
                    'uid' : uid,
                    'cid' : cid, 
                }
        return render(request,"myapp/index.html",context)
    else:
        if request.POST:
            email=request.POST['emailname']
            password=request.POST['passwordname']
            print("---->email",email)
            
            uid = user.objects.get(email=email)
            print("--->", uid.password)
            print("--->",uid.role)
            
            if uid.password == password:
                if uid.role == "cafeowner":
                    cid = cafe_owner.objects.get(user_id = uid)
                    print("--->",cid.username)
                    print("--->",cid.contact)
                    request.session['email'] = uid.email
                context = {
                    'uid' : uid,
                    'cid' : cid, 
                }
                
                return render(request,"myapp/index.html",context)
            else:
                e_msg = "invalid password"
                context = {
                    'e_msg' : e_msg
                }
                return render(request,"myapp/login.html",context)

            
        else:
            print("----> login page refresed")
            return render(request,"myapp/login.html")
        
def logout(request):
    if "email" in request.session:
        del request.session['email']
        return render(request,"myapp/login.html")
    else:
        return render(request,"myapp/login.html")

def cafe_owner_profile(request):
    if "email" in request.session:
        uid = user.objects.get(email = request.session['email'])
        cid = cafe_owner.objects.get(user_id = uid) 
        context = {
                    'uid' : uid,
                    'cid' : cid, 
                }
 
        return render(request,"myapp/profile.html",context)
    else:
        return render(request,"myapp/login.html")

def cafe_password_change(request):
    if "email" in request.session:
        uid = user.objects.get(email = request.session['email'])
        cid = cafe_owner.objects.get(user_id = uid)
        if request.POST:
            # print("====? current password ")
            currentpassword = request.POST['currentpassword']
            newpassword = request.POST['newpassword']
            
            print("--------------------",currentpassword)
            if uid.password == currentpassword:
                # print("--------------------=================")
                uid.password = newpassword
                uid.save()
                return redirect("logout")
                # return render(request,"myapp/profile.html")
            else:
                return HttpResponse("password changed")    
        else:        
            context = {
                "uid":uid,
                "cid":cid,
            }
            return render(request,"myapp/profile.html",context)
    else:
        return render(request,"myapp/profile.html")

def cafe_owner_pic_change(request):
    if "email" in request.session:
        uid = user.objects.get(email = request.session['email'])
        cid = cafe_owner.objects.get(user_id = uid)
        if request.POST:
            if 'pic' in request.FILES:
                pic = request.FILES["pic"]
                cid.pic = pic
                cid.save()
            return redirect("profile")


def add_product(request):
    if "email" in request.session:
        uid = user.objects.get(email = request.session['email'])
        cid = cafe_owner.objects.get(user_id = uid)
        c_all = category.objects.all() #fatch all data from table
        if request.POST:
            c_name = request.POST["category_id"] 
            print("-----> category id",c_name)
            category_id = category.objects.get(category_name = c_name)
            # print("-----------------------------",category_id)
            
            if 'pic' in request.FILES:
                pid=products.objects.create(
                    user_id = uid,
                    category_id = category_id,
                    product_name = request.POST['product_name'],
                    discription = request.POST["discription"],
                    food_type = request.POST["food_type"],
                    price = request.POST["price"],
                    pic = request.FILES['pic'],   
                )
                
                if pid:
                    s_msg = "you have successfully added product."
                    return render(request,"myapp/add-product.html",{'s_msg':s_msg})

                else:
                    context = {
                        'uid' : uid,
                        'cid' : cid,   
                        'c_all':c_all,
                        's_msg':s_msg,
                    }
                    return render(request,"myapp/add-product.html",context)
            else:
                pid=products.objects.create(
                    user_id = uid,
                    category_id = category_id,
                    product_name = request.POST['product_name'],
                    discription = request.POST["discription"],
                    food_type = request.POST["food_type"],
                    price = request.POST["price"],
                    # pic = request.FILES['pic'],   
                )
                
                if pid:
                    s_msg = "you have successfully added product."
                    return render(request,"myapp/add-product.html",{'s_msg':s_msg})

                else:
                    context = {
                        'uid' : uid,
                        'cid' : cid,   
                        'c_all':c_all,
                        's_msg':s_msg,
                    }
                    return render(request,"myapp/add-product.html",context)

        else:
            context = {
                'uid' : uid,
                'cid' : cid,   
                'c_all':c_all
            }
            return render(request,"myapp/add-product.html",context)
        
def all_product(request):
    if "email" in request.session:
        uid = user.objects.get(email = request.session['email'])
        cid = cafe_owner.objects.get(user_id = uid)
        pall = products.objects.filter(user_id = uid)
        c_all = category.objects.all()
        context = {
            'uid' : uid,
            'cid' : cid,
            'pall' : pall, 
            'c_all' : c_all,
            
        }
    return render(request,"myapp/all-products.html",context)

def search_product(request):
    if "email" in request.session:
        uid = user.objects.get(email = request.session['email'])
        cid = cafe_owner.objects.get(user_id = uid)
        
        category_id = request.POST['category_id_search']
        categoryid = category.objects.get(category_name = category_id)
        
        pall = products.objects.filter(user_id = uid,category_id = categoryid)
        c_all = category.objects.all()
        
        context = {
            'uid' : uid,
            'cid' : cid,
            'pall' : pall, 
            'c_all' : c_all,
            
        }
    return render(request,"myapp/all-products.html",context)

def edit_product(request,pk):
    print("====>",pk)
    if "email" in request.session:
        uid = user.objects.get(email = request.session['email'])
        pid = products.objects.get(id=pk)
        cid = cafe_owner.objects.get(user_id = uid)
        pall = products.objects.filter(user_id = uid)
        context = {
            'uid' : uid,
            'cid' : cid,
            'pall' : pall, 
            'pid' : pid,
           
        }
    return render(request,"myapp/edit-product.html",context)

def update_product(request):
    if "email" in request.session:
        uid = user.objects.get(email = request.session['email'])
        cid = cafe_owner.objects.get(user_id = uid)
        pall = products.objects.filter(user_id = uid)
        
        if request.POST:
            pid = products.objects.get(id = request.POST['product_id'])
            if "category_id" in request.POST:
                category_name = request.POST['category_id']
                pid.category_id = category.objects.get(category_name = category_name)
            pid.product_name = request.POST['product_name']
            pid.discription = request.POST["discription"]
            pid.food_type = request.POST["food_type"]
            pid.price = request.POST["price"]
                    
            if "pic" in request.FILES:        
                    pid.pic = request.FILES['pic']
            pid.save()
            
        context = {
            'uid' : uid,
            'cid' : cid,
            'pall' : pall,
           
            }
        return render(request,"myapp/edit-product.html",context)

    