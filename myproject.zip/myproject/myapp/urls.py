"""myproject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from myapp import views

urlpatterns = [
    path('home', views.home, name='home'),
    path('',views.login,name = 'login'),
    path('logout/',views.logout,name='logout'),
    path('profile/',views.cafe_owner_profile,name='profile'),
    path('cafe-password-change',views.cafe_password_change,name='cafe-password-change'),
    path('cafe-owner-pic-change/',views.cafe_owner_pic_change,name='cafe-owner-pic-change'),
    path('add-product',views.add_product,name='add-product'),
    path('all-product',views.all_product,name='all-product'),
    path('search-product',views.search_product,name='search-product'),
    path('edit-product/<int:pk>',views.edit_product,name='edit-product'),
    path('update/',views.update_product,name='update-product'),
]
