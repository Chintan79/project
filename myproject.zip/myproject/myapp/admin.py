from django.contrib import admin
from . models import *

# Register your models here.

admin.site.register(user)
admin.site.register(cafe_owner)
admin.site.register(category)
admin.site.register(products)